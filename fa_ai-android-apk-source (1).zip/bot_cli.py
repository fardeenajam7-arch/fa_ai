"""
FA AI - Terminal CLI Context-Aware AI Chatbot
Author: Fardeen Ajam

Run this directly on any computer with Python 3:
    pip install requests
    python bot_cli.py
"""

import sys
import os
import json
import requests
from datetime import datetime

# ANSI Colors for beautiful terminal output
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
BOLD = "\033[1m"
RESET = "\033[0m"


class FAAIChatbot:
    def __init__(self, api_key=None):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.history = []
        self.system_prompt = (
            "You are FA AI, a friendly, intelligent, and context-aware "
            "AI assistant. You provide concise, insightful explanations, clean code examples, "
            "and remember conversational details across turns."
        )

    def ask(self, query):
        if not self.api_key:
            return "Please provide your GEMINI_API_KEY (export GEMINI_API_KEY='your-key')."

        # Context-aware turn tracking
        self.history.append({"role": "user", "parts": [{"text": query}]})

        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={self.api_key}"

        payload = {
            "system_instruction": {
                "parts": [{"text": self.system_prompt}]
            },
            "contents": self.history,
            "generationConfig": {
                "temperature": 0.7,
                "topP": 0.95,
                "maxOutputTokens": 2048
            }
        }

        try:
            res = requests.post(endpoint, json=payload, timeout=30)
            if res.status_code == 200:
                reply = res.json()["candidates"][0]["content"]["parts"][0]["text"]
                self.history.append({"role": "model", "parts": [{"text": reply}]})
                return reply
            else:
                return f"[API Error {res.status_code}]: {res.text}"
        except Exception as e:
            return f"[Connection Error]: {str(e)}"

    def save_history(self, filename="fa_ai_chat.json"):
        with open(filename, "w") as f:
            json.dump(self.history, f, indent=2)
        print(f"{GREEN}✓ Chat history saved to {filename}{RESET}")


def main():
    print(f"{CYAN}{BOLD}===================================================={RESET}")
    print(f"{CYAN}{BOLD}       FA AI - Intelligent Natural Language Assistant     {RESET}")
    print(f"{CYAN}{BOLD}===================================================={RESET}")
    print("Commands: 'exit' to quit | 'clear' to reset memory | 'save' to export chat\n")

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        api_key = input(f"{YELLOW}Enter your Gemini API Key: {RESET}").strip()

    bot = FAAIChatbot(api_key=api_key)
    print(f"{GREEN}FA AI is ready! Ask your question below:{RESET}\n")

    while True:
        try:
            user_input = input(f"{BOLD}You > {RESET}").strip()
            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit", "q"]:
                print(f"{MAGENTA}Goodbye from FA AI! Have a great day.{RESET}")
                break

            if user_input.lower() == "clear":
                bot.history = []
                print(f"{YELLOW}✓ Memory wiped. Starting a fresh context.{RESET}\n")
                continue

            if user_input.lower() == "save":
                bot.save_history()
                continue

            print(f"{CYAN}FA AI is generating...{RESET}")
            response = bot.ask(user_input)
            print(f"\n{CYAN}{BOLD}FA AI >{RESET}\n{response}\n")

        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit(0)


if __name__ == "__main__":
    main()
