"""
FA AI - Android APK Mobile Chatbot (Kivy & Python)
Author: Fardeen Ajam
App Name: FA AI
Version: 1.0.0

This is a production-ready, threaded mobile application designed to be compiled
into an Android .apk file using Buildozer. It supports context-aware natural
language conversation with the Gemini REST API and handles network delays
gracefully via background worker threads.
"""

import json
import threading
import os
from datetime import datetime

# Kivy core imports
from kivy.app import App
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.utils import get_color_from_hex
from kivy.metrics import dp

# HTTP request handler compatible with Android / Kivy
import requests

# Set default soft keyboard behavior on Android
Window.softinput_mode = "below_target"

# KV Interface Definition with Material Design aesthetic
KV_DESIGN = '''
#:import get_color_from_hex kivy.utils.get_color_from_hex

<MessageBubble@BoxLayout>:
    orientation: 'vertical'
    size_hint_y: None
    height: self.minimum_height
    padding: [dp(12), dp(8)]
    spacing: dp(4)

    # Bubble background
    canvas.before:
        Color:
            rgba: root.bubble_color
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(16), dp(16), dp(16), dp(4)] if root.is_user else [dp(16), dp(16), dp(4), dp(16)]

    Label:
        id: sender_label
        text: root.sender_title
        size_hint_y: None
        height: dp(18)
        font_size: '12sp'
        bold: True
        color: root.sender_color
        halign: 'right' if root.is_user else 'left'
        text_size: self.width, None

    Label:
        id: message_label
        text: root.message_text
        size_hint_y: None
        height: self.texture_size[1] + dp(4)
        font_size: '15sp'
        color: get_color_from_hex("#FFFFFF") if root.is_user else get_color_from_hex("#E2E8F0")
        halign: 'left'
        valign: 'top'
        text_size: self.width, None

    Label:
        id: time_label
        text: root.timestamp_text
        size_hint_y: None
        height: dp(14)
        font_size: '10sp'
        color: get_color_from_hex("#94A3B8")
        halign: 'right' if root.is_user else 'left'
        text_size: self.width, None

<ChatScreen>:
    orientation: 'vertical'
    canvas.before:
        Color:
            rgba: get_color_from_hex("#0F172A")
        Rectangle:
            pos: self.pos
            size: self.size

    # Top App Bar
    BoxLayout:
        size_hint_y: None
        height: dp(60)
        padding: [dp(16), dp(8)]
        spacing: dp(12)
        canvas.before:
            Color:
                rgba: get_color_from_hex("#1E293B")
            Rectangle:
                pos: self.pos
                size: self.size

        # Avatar Icon
        Label:
            text: "FA"
            size_hint: None, None
            size: dp(40), dp(40)
            bold: True
            font_size: '16sp'
            color: get_color_from_hex("#38BDF8")
            canvas.before:
                Color:
                    rgba: get_color_from_hex("#0369A1")
                Ellipse:
                    pos: self.pos
                    size: self.size

        # App Title & Subtitle
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(2)
            Label:
                text: "FA AI"
                bold: True
                font_size: '18sp'
                color: get_color_from_hex("#F8FAFC")
                halign: 'left'
                text_size: self.width, None
            Label:
                text: "Context-Aware AI Assistant"
                font_size: '12sp'
                color: get_color_from_hex("#38BDF8")
                halign: 'left'
                text_size: self.width, None

        # Settings Button
        Button:
            text: "⚙"
            size_hint: None, None
            size: dp(40), dp(40)
            background_normal: ''
            background_color: get_color_from_hex("#334155")
            color: get_color_from_hex("#F8FAFC")
            font_size: '18sp'
            on_release: app.open_settings_popup()

        # Clear Chat Button
        Button:
            text: "🗑"
            size_hint: None, None
            size: dp(40), dp(40)
            background_normal: ''
            background_color: get_color_from_hex("#334155")
            color: get_color_from_hex("#F8FAFC")
            font_size: '16sp'
            on_release: root.clear_conversation()

    # Chat Messages Scroll Area
    ScrollView:
        id: chat_scroll
        do_scroll_x: False
        do_scroll_y: True
        effect_cls: 'ScrollEffect'

        BoxLayout:
            id: messages_container
            orientation: 'vertical'
            size_hint_y: None
            height: self.minimum_height
            padding: [dp(16), dp(16)]
            spacing: dp(14)

    # Typing Indicator Banner (Hidden by default)
    Label:
        id: status_label
        text: ""
        size_hint_y: None
        height: dp(20) if self.text else dp(0)
        font_size: '12sp'
        color: get_color_from_hex("#38BDF8")
        halign: 'center'

    # Bottom Input Bar
    BoxLayout:
        size_hint_y: None
        height: dp(64)
        padding: [dp(12), dp(8)]
        spacing: dp(8)
        canvas.before:
            Color:
                rgba: get_color_from_hex("#1E293B")
            Rectangle:
                pos: self.pos
                size: self.size

        TextInput:
            id: message_input
            multiline: False
            hint_text: "Ask FA AI anything..."
            hint_text_color: get_color_from_hex("#64748B")
            foreground_color: get_color_from_hex("#F8FAFC")
            background_color: get_color_from_hex("#0F172A")
            cursor_color: get_color_from_hex("#38BDF8")
            padding: [dp(12), dp(10)]
            font_size: '15sp'
            on_text_validate: root.send_user_message()

        Button:
            id: send_button
            text: "Send"
            size_hint_x: None
            width: dp(75)
            bold: True
            font_size: '14sp'
            background_normal: ''
            background_color: get_color_from_hex("#0284C7")
            color: get_color_from_hex("#FFFFFF")
            on_release: root.send_user_message()
'''

Builder.load_string(KV_DESIGN)


class MessageBubble(BoxLayout):
    def __init__(self, sender, text, is_user=False, **kwargs):
        self.is_user = is_user
        self.sender_title = "You" if is_user else "FA AI"
        self.message_text = text
        self.timestamp_text = datetime.now().strftime("%I:%M %p")

        if is_user:
            self.bubble_color = get_color_from_hex("#0369A1")  # Blue accent
            self.sender_color = get_color_from_hex("#BAE6FD")
        else:
            self.bubble_color = get_color_from_hex("#1E293B")  # Slate dark
            self.sender_color = get_color_from_hex("#38BDF8")

        super().__init__(**kwargs)


class ChatScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Context-aware conversation history stored as list of turns
        self.conversation_history = []
        
        # Add friendly welcome message
        Clock.schedule_once(lambda dt: self.add_assistant_message(
            "Hello! I am FA AI, your natural language assistant.\n"
            "Ask me questions, ask for coding help, or chat naturally. "
            "I remember our conversation context!"
        ), 0.3)

    def add_user_message(self, text):
        bubble = MessageBubble(sender="You", text=text, is_user=True)
        self.ids.messages_container.add_widget(bubble)
        self.scroll_to_bottom()

    def add_assistant_message(self, text):
        bubble = MessageBubble(sender="FA AI", text=text, is_user=False)
        self.ids.messages_container.add_widget(bubble)
        self.scroll_to_bottom()

    def scroll_to_bottom(self):
        Clock.schedule_once(lambda dt: setattr(self.ids.chat_scroll, 'scroll_y', 0), 0.1)

    def send_user_message(self):
        query = self.ids.message_input.text.strip()
        if not query:
            return

        # Clear text input immediately
        self.ids.message_input.text = ""
        self.ids.status_label.text = "FA AI is thinking..."
        self.ids.send_button.disabled = True

        # Render user message
        self.add_user_message(query)

        # Append to conversational memory
        self.conversation_history.append({"role": "user", "parts": [{"text": query}]})

        # Run API call in background thread to prevent UI freezing on Android
        threading.Thread(target=self._query_ai_worker, args=(query,), daemon=True).start()

    def _query_ai_worker(self, user_query):
        app = App.get_running_app()
        api_key = app.get_api_key()

        # If no custom API key is set, use the provided fallback or test response
        if not api_key:
            response_text = (
                "⚠️ Notice: No Gemini API Key is configured yet.\n\n"
                "To connect to live Gemini intelligence:\n"
                "1. Tap the ⚙ Settings icon in the top right.\n"
                "2. Paste your Google AI Studio API Key.\n"
                "3. Tap 'Save'.\n\n"
                f"[Simulated Context Response]: I received your query: '{user_query}'."
            )
            Clock.schedule_once(lambda dt: self._on_ai_response(response_text, False), 0.5)
            return

        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"

        payload = {
            "system_instruction": {
                "parts": [{"text": app.get_system_prompt()}]
            },
            "contents": self.conversation_history,
            "generationConfig": {
                "temperature": 0.7,
                "topP": 0.95,
                "maxOutputTokens": 2048
            }
        }

        try:
            res = requests.post(
                endpoint,
                headers={"Content-Type": "application/json"},
                json=payload,
                timeout=25
            )

            if res.status_code == 200:
                data = res.json()
                reply = data["candidates"][0]["content"]["parts"][0]["text"]
                Clock.schedule_once(lambda dt: self._on_ai_response(reply, True), 0)
            else:
                err_msg = f"API Error ({res.status_code}): {res.text}"
                Clock.schedule_once(lambda dt: self._on_ai_response(err_msg, False), 0)

        except requests.exceptions.Timeout:
            Clock.schedule_once(lambda dt: self._on_ai_response("Network timeout. Please check your internet connection.", False), 0)
        except Exception as e:
            Clock.schedule_once(lambda dt: self._on_ai_response(f"Connection error: {str(e)}", False), 0)

    def _on_ai_response(self, reply_text, is_success):
        self.ids.status_label.text = ""
        self.ids.send_button.disabled = False
        self.add_assistant_message(reply_text)

        if is_success:
            # Keep assistant response in conversation memory
            self.conversation_history.append({"role": "model", "parts": [{"text": reply_text}]})

    def clear_conversation(self):
        self.ids.messages_container.clear_widgets()
        self.conversation_history = []
        self.add_assistant_message("Conversation cleared. How can FA AI assist you now?")


class FAAIApp(App):
    def build(self):
        self.title = "FA AI - Context-Aware Chatbot"
        self.config_file = os.path.join(self.user_data_dir, "fa_ai_config.json")
        self.load_settings()
        return ChatScreen()

    def get_api_key(self):
        return self.settings_data.get("api_key", os.environ.get("GEMINI_API_KEY", ""))

    def get_system_prompt(self):
        default_prompt = (
            "You are FA AI, a helpful, brilliant, and friendly AI assistant. "
            "You process natural language questions, remember conversation context, "
            "provide accurate explanations, code snippets, and structured guidance."
        )
        return self.settings_data.get("system_prompt", default_prompt)

    def load_settings(self):
        self.settings_data = {}
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    self.settings_data = json.load(f)
            except Exception:
                self.settings_data = {}

    def save_settings(self, api_key, system_prompt):
        self.settings_data["api_key"] = api_key.strip()
        self.settings_data["system_prompt"] = system_prompt.strip()
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.settings_data, f)
        except Exception as e:
            print("Failed to save settings:", e)

    def open_settings_popup(self):
        content = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(12))

        content.add_widget(Label(
            text="Gemini API Key:",
            size_hint_y=None,
            height=dp(24),
            halign='left',
            font_size='14sp',
            bold=True
        ))
        
        api_input = TextInput(
            text=self.get_api_key(),
            password=True,
            multiline=False,
            size_hint_y=None,
            height=dp(42),
            font_size='13sp'
        )
        content.add_widget(api_input)

        content.add_widget(Label(
            text="System Instructions:",
            size_hint_y=None,
            height=dp(24),
            halign='left',
            font_size='14sp',
            bold=True
        ))

        prompt_input = TextInput(
            text=self.get_system_prompt(),
            multiline=True,
            size_hint_y=None,
            height=dp(90),
            font_size='12sp'
        )
        content.add_widget(prompt_input)

        btn_box = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(10))
        
        save_btn = Button(
            text="Save & Close",
            bold=True,
            background_color=get_color_from_hex("#0284C7")
        )
        cancel_btn = Button(
            text="Cancel",
            background_color=get_color_from_hex("#475569")
        )
        btn_box.add_widget(cancel_btn)
        btn_box.add_widget(save_btn)
        content.add_widget(btn_box)

        popup = Popup(
            title="FA AI Settings",
            content=content,
            size_hint=(0.9, 0.7),
            auto_dismiss=False
        )

        def save_and_dismiss(instance):
            self.save_settings(api_input.text, prompt_input.text)
            popup.dismiss()

        save_btn.bind(on_release=save_and_dismiss)
        cancel_btn.bind(on_release=popup.dismiss)
        popup.open()


if __name__ == '__main__':
    FAAIApp().run()
