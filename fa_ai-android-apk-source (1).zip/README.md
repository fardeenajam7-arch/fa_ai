# FA AI - Android APK & Python Chatbot

An intelligent, context-aware natural language conversational chatbot created in Python.

## 📱 Features
- **Context-Aware Memory**: Remembers previous turns and context during conversational interaction.
- **Android APK Ready**: Pre-configured with Kivy and Buildozer to package into a standalone Android APK.
- **Background Threading**: No ANR (Application Not Responding) freezes during AI generation.
- **Settings Panel**: On-device API key and system prompt configuration without recompiling.
- **Terminal CLI Mode**: Standalone Python script for desktop / server use.

---

## 🚀 How to Build the Android APK (Choose 1 Method)

### Method 1: Free GitHub Actions (Recommended - No Linux Needed!)
This is the fastest method if you are on Windows or Mac:
1. Create a free repository on [GitHub.com](https://github.com).
2. Upload these project files:
   - `main.py`
   - `buildozer.spec`
   - `.github/workflows/build-apk.yml`
3. Go to the **Actions** tab in your repository.
4. Click **Run workflow**.
5. Wait ~8 minutes. Once complete, click on the workflow run and download **`fa_ai-debug-apk`**!
6. Transfer the `.apk` to your Android phone, enable "Install unknown apps", and open **FA AI**!

---

### Method 2: Google Colab (Free Cloud Linux)
1. Go to [Google Colab](https://colab.research.google.com).
2. Create a new notebook and select Runtime -> Python 3.
3. Upload `main.py` and `buildozer.spec`.
4. Run:
   ```bash
   !pip install Cython==0.29.36 buildozer
   !sudo apt-get update && sudo apt-get install -y openjdk-17-jdk libssl-dev
   !buildozer android debug
   ```
5. Download the `.apk` from the `bin/` folder.

---

### Method 3: Local Ubuntu / WSL (Windows Subsystem for Linux)
Run inside terminal:
```bash
sudo apt update && sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
pip install --user --upgrade Cython==0.29.36 buildozer
buildozer android debug
```
Your APK will be ready in the `bin/` folder!
