# ==============================================================================
# Google Colab 1-Click APK Generator for FA AI
# Open https://colab.research.google.com, create a new notebook, paste and RUN:
# ==============================================================================

# 1. Install Buildozer dependencies
!sudo apt-get update -qq
!sudo apt-get install -y -qq build-essential git ffmpeg libsdl2-dev libsdl2-image-dev \
    libsdl2-mixer-dev libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev \
    libavcodec-dev zlib1g-dev openjdk-17-jdk autoconf libtool pkg-config libssl-dev zip unzip

# 2. Install Buildozer and Cython
!pip install --upgrade pip
!pip install Cython==0.29.36 buildozer

# 3. Create or upload main.py and buildozer.spec
# (Upload the zip project files or create them directly)

# 4. Run Buildozer to compile the APK
!buildozer android debug

# 5. Download the compiled APK to your PC / Android phone!
from google.colab import files
import glob

apk_files = glob.glob("bin/*.apk")
if apk_files:
    print("Download started:", apk_files[0])
    files.download(apk_files[0])
else:
    print("Build output check bin folder")
